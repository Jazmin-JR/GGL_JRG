import React from 'react';
import { View, Text, Image, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';

const DetailScreen = ({ route }) => {
  const { post } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{post.title.rendered}</Text>
      <Image
        source={{ uri: post._embedded['wp:featuredmedia'][0].source_url }}
        style={styles.image}
        resizeMode="cover"
      />
      <Text style={styles.author}>Autor: {post.author}</Text>
      <Text style={styles.content}>
        {post.content.rendered.replace(/<[^>]+>/g, '')}
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff'  
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333'  
  },
  image: {
    width: '100%',
    height: 200,
    marginBottom: 10
  },
  author: {
    fontStyle: 'italic',
    marginBottom: 10,
    color: '#666'  
  },
  content: {
    fontSize: 16,
    color: '#444', 
    lineHeight: 24,
    textAlign: 'justify'
  }
});

export default DetailScreen;
