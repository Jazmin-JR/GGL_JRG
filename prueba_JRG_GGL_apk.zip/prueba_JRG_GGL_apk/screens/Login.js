import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, Image } from 'react-native';

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Validar las credenciales
    if (username === 'usuario' && password === 'contraseña') {
      // Credenciales válidas, acción de inicio de sesión
      Alert.alert('Inicio de sesión exitoso', `¡Bienvenido, ${username}!`);
      navigation.navigate('List');
    } else {
      // Credenciales inválidas, mensajes de error
      Alert.alert('Error', 'Usuario o contraseña incorrectos');
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/userlog.png')} 
        style={styles.image}
      />
      <TextInput
        style={styles.input}
        placeholder="Usuario"
        onChangeText={setUsername}
        value={username}
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        onChangeText={setPassword}
        value={password}
        secureTextEntry
      />
      <TouchableOpacity
        style={styles.button}
        onPress={handleLogin}
      >
        <Text style={styles.buttonText}>Iniciar sesión</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  input: {
    width: '80%',
    marginBottom: 20,
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 25,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: 'green', 
    borderRadius: 25, 
    paddingHorizontal: 20,
    paddingVertical: 12,
    width: '80%', 
  },
  buttonText: {
    color: '#fff', 
    textAlign: 'center', 
    fontWeight: 'bold', 
  },
  image: {
    width: 100, 
    height: 100, 
    marginBottom: 20, 
},
});

export default LoginScreen;
